# Guidance values for HEAT_TRANSFER_COEFFICIENT_SOLID on a solid particle resting on a surface

h_s in W/m2/K, per unit footprint (projected) area. Gas-gap conduction only, uniform stand-off s. Air at a mean gap temperature of 700 K (k = 0.0524 W/m/K);
multiply by 0.50 for 300 K, 0.78 for 500 K, 1.18 for 900 K.

| Particle | s = 0.01 mm | 0.03 mm | 0.1 mm | 0.3 mm | 1 mm |
|---|---|---|---|---|---|
| Sphere, r = 5 mm | 110 | 87 | 63 | 43 | 24 |
| Sphere, r = 2 mm | 227 | 172 | 115 | 70 | 34 |
| Cylinder lying flat, r = 3.2 mm | 610 | 336 | 168 | 84 | 36 |
| Cylinder lying flat, r = 1 mm | 1038 | 552 | 259 | 118 | 44 |
| Flat plate (any size) | 5240 | 1747 | 524 | 175 | 52 |

Check of the closed forms against numerical integration (s = 0.1 mm): sphere 1.000000, cylinder 1.000000.
For comparison, linearised black-body radiation between 1100 K and 300 K is about 100 W/m2/K; FDS already includes radiation separately.
Real solid-solid contact adds little: for a sub-gram ember under its own weight the real contact area is of order 1e-6 of the footprint or less (Cooper, Mikic and Yovanovich 1969).
