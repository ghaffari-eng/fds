"""Guidance values for HEAT_TRANSFER_COEFFICIENT_SOLID (h_s) for a solid particle resting on a flat surface.

h_s is the gas-gap conductance G divided by the particle footprint (projected) area A_c, the area FDS uses:
  sphere pi R^2, cylinder lying flat 2 R L, plate L W.
Model: one-dimensional conduction across the local gas gap under an isothermal particle (Batchelor and O'Brien 1977, wall limit;
Rong and Horio 1999; Morris et al. 2015), with a uniform stand-off s (ash, char roughness), integrated over the footprint.
  sphere:   G = 2 pi k [ (R+s) ln((R+s)/s) - R ]
  cylinder: G = k L [ 4a/sqrt(a^2-R^2) atan( sqrt((a+R)/(a-R)) ) - pi ],  a = R + s
  plate:    G = k L W / s
Each closed form is checked here against direct numerical integration of k/gap(x) over the footprint.
Air conductivity: Incropera et al., Fundamentals of Heat and Mass Transfer, Table A.4 (at the mean gap temperature).
Radiation across the gap is NOT included: FDS already carries the particle's radiation to the surface through the radiation solver.
"""
import math, numpy as np
from scipy.integrate import quad
k_air = {300: 0.0263, 500: 0.0407, 700: 0.0524, 900: 0.0620}   # W/m/K, Incropera Table A.4
def G_sphere(k, R, s):   return 2*math.pi*k*((R+s)*math.log((R+s)/s) - R)
def G_cyl(k, R, L, s):
    a = R + s; return k*L*(4*a/math.sqrt(a*a-R*R)*math.atan(math.sqrt((a+R)/(a-R))) - math.pi)
def G_plate(k, L, W, s): return k*L*W/s
def check():
    R, L, s, k = 0.005, 0.038, 1e-4, 0.05
    num_s = quad(lambda r: k/(s+R-math.sqrt(R*R-r*r))*2*math.pi*r, 0, R, limit=200, points=[R])[0]
    num_c = 2*L*quad(lambda x: k/(s+R-math.sqrt(R*R-x*x)), 0, R, limit=200, points=[R])[0]
    return num_s/G_sphere(k, R, s), num_c/G_cyl(k, R, L, s)
r1, r2 = check()
shapes = [('Sphere, r = 5 mm', lambda k, s: G_sphere(k, 0.005, s)/(math.pi*0.005**2)),
          ('Sphere, r = 2 mm', lambda k, s: G_sphere(k, 0.002, s)/(math.pi*0.002**2)),
          ('Cylinder lying flat, r = 3.2 mm', lambda k, s: G_cyl(k, 0.0032, 0.038, s)/(2*0.0032*0.038)),
          ('Cylinder lying flat, r = 1 mm', lambda k, s: G_cyl(k, 0.001, 0.02, s)/(2*0.001*0.02)),
          ('Flat plate (any size)', lambda k, s: G_plate(k, 0.02, 0.02, s)/(0.02*0.02))]
gaps = [1e-5, 3e-5, 1e-4, 3e-4, 1e-3]
out = ['# Guidance values for HEAT_TRANSFER_COEFFICIENT_SOLID on a solid particle resting on a surface', '',
       'h_s in W/m2/K, per unit footprint (projected) area. Gas-gap conduction only, uniform stand-off s. Air at a mean gap temperature of 700 K (k = 0.0524 W/m/K);',
       'multiply by 0.50 for 300 K, 0.78 for 500 K, 1.18 for 900 K.', '',
       '| Particle | s = 0.01 mm | 0.03 mm | 0.1 mm | 0.3 mm | 1 mm |', '|---|---|---|---|---|---|']
for name, f in shapes:
    out.append(f'| {name} | ' + ' | '.join(f'{f(k_air[700], s):.0f}' for s in gaps) + ' |')
out += ['', f'Check of the closed forms against numerical integration (s = 0.1 mm): sphere {r1:.6f}, cylinder {r2:.6f}.',
        'For comparison, linearised black-body radiation between 1100 K and 300 K is about 100 W/m2/K; FDS already includes radiation separately.',
        'Real solid-solid contact adds little: for a sub-gram ember under its own weight the real contact area is of order 1e-6 of the footprint (Cooper, Mikic and Yovanovich 1969).']
print('\n'.join(out)); open('hs_guidance.md', 'w').write('\n'.join(out)+'\n')
