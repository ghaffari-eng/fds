"""Compare the baseline FDS runs with the analytical expectations. Writes summary.md and plots."""
import sys, csv, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R = sys.argv[1]  # results folder
SIG = 5.670374419e-8
T_inf = 293.15

def read_fds_csv(path):
    with open(path) as f:
        rows = list(csv.reader(f))
    names = [n.strip() for n in rows[1]]
    data = np.array([[float(v) for v in r] for r in rows[2:] if r])
    return {n: data[:, i] for i, n in enumerate(names)}

out = ['# Baseline on unmodified FDS (branch = current master)', '']

# ---- Case A: fixed-temperature sphere
r, eps, Tp = 0.005, 0.7, 900 + 273.15
A = 4 * math.pi * r**2
Q_exp = eps * A * SIG * (Tp**4 - T_inf**4)          # W, net loss to 20 C black surroundings
h = r                                                # height of sphere centre above floor
Rf = 0.2                                             # half-width of floor (approx. as disc of radius 0.2 m)
frac_floor = 0.5 * (1 - h / math.sqrt(h**2 + Rf**2))  # share of isotropic emission reaching the floor
out += ['## A. 900 C sphere (r = 5 mm, emissivity 0.7) resting on a 20 C black floor, radiation only', '',
        f'Expected particle net radiative loss: {Q_exp:.2f} W',
        f'Expected share reaching the floor (convex body on a plane = 0.5; finite floor: {frac_floor:.3f})', '',
        '| Angles | Particle loss (W) | vs expected | Floor gain (W) | Floor / particle | Flux in floor cell under sphere (kW/m2) |',
        '|---|---|---|---|---|---|']
fig, ax = plt.subplots()
for N in (104, 400):
    d = read_fds_csv(f'{R}/hot_sphere_floor_{N}_devc.csv')
    m = d['Time'] > 2.0
    Qp = -1000 * d['Q_part_rad'][m].mean()  # FDS reports particle radiation loss as negative
    Qf = 1000 * d['Q_floor_rad'][m].mean()
    qu = d['q_floor_under'][m].mean()
    out.append(f'| {N} | {Qp:.2f} | {100*(Qp/Q_exp-1):+.1f}% | {Qf:.2f} | {Qf/Qp:.3f} | {qu:.2f} |')
    try:
        L = read_fds_csv(f'{R}/hot_sphere_floor_{N}_line.csv')
        xk = [k for k in L if k.endswith('-x')][0]
        ax.plot(L[xk], L['qr_x'], marker='o', ms=3, label=f'{N} angles')
    except Exception as e:
        out.append(f'(line output not read for {N}: {e})')
ax.set_xlabel('x (m)'); ax.set_ylabel('Net radiative flux into floor (kW/m$^2$)')
ax.set_title('Floor flux along a line through the sphere (unmodified FDS)'); ax.legend(); ax.grid(alpha=0.3)
fig.savefig(f'{R}/hot_sphere_floor_profile.png', dpi=150, bbox_inches='tight')
out += ['', 'If the sphere heat landed only under its own footprint (pi r^2 = '
        f'{math.pi*r**2*1e6:.1f} mm2), the footprint flux would be of order {0.5*Q_exp/(math.pi*r**2)/1000:.0f} kW/m2; '
        'FDS spreads it over floor cells (1 cm x 1 cm here).', '']

# ---- Case C: cooling steel sphere, lumped analytical solution (radiation only)
rho, c, eps = 7850., 460., 0.8
m_c = rho * 4/3 * math.pi * r**3 * c
d = read_fds_csv(f'{R}/steel_sphere_cooling_devc.csv')
t = d['Time']; T_fds = d['T_sphere'] + 273.15
T_an = np.empty_like(t); T_an[0] = 900 + 273.15
for i in range(1, len(t)):
    dt = t[i] - t[i-1]; T = T_an[i-1]
    f = lambda T: -eps * A * SIG * (T**4 - T_inf**4) / m_c
    k1 = f(T); k2 = f(T + 0.5*dt*k1); k3 = f(T + 0.5*dt*k2); k4 = f(T + dt*k3)
    T_an[i] = T + dt * (k1 + 2*k2 + 2*k3 + k4) / 6
err = np.max(np.abs(T_fds - T_an))
out += ['## C. 900 C steel sphere (r = 5 mm, emissivity 0.8) cooling on a 20 C floor, radiation only', '',
        f'Lumped (Bi << 1) analytical solution: m c dT/dt = -eps A sigma (T^4 - T_inf^4), m c = {m_c:.3f} J/K', '',
        f'Temperature at 60 s: FDS {T_fds[np.argmin(abs(t-60))]-273.15:.1f} C, analytical {T_an[np.argmin(abs(t-60))]-273.15:.1f} C',
        f'Temperature at 120 s: FDS {T_fds[-1]-273.15:.1f} C, analytical {T_an[-1]-273.15:.1f} C',
        f'Maximum difference over 0-120 s: {err:.1f} K', '',
        'Today the floor does not change how fast the particle cools: there is no conduction path.']
fig, ax = plt.subplots()
ax.plot(t, T_fds - 273.15, label='FDS (unmodified)'); ax.plot(t, T_an - 273.15, '--', label='Analytical, radiation only')
ax.set_xlabel('Time (s)'); ax.set_ylabel('Sphere temperature (C)'); ax.legend(); ax.grid(alpha=0.3)
ax.set_title('Steel sphere cooling on a cold floor')
fig.savefig(f'{R}/steel_sphere_cooling.png', dpi=150, bbox_inches='tight')

open(f'{R}/summary.md', 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
