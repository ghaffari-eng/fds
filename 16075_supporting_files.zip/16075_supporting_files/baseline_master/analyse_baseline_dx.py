"""Cell-size sweep for the resting hot sphere, plus 5 cm cooling case, on unmodified FDS. Writes summary_dx.md and a plot."""
import sys, csv, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R = sys.argv[1]
SIG, T_inf = 5.670374419e-8, 293.15
def read_fds_csv(path):
    rows = list(csv.reader(open(path)))
    names = [n.strip() for n in rows[1]]
    data = np.array([[float(v) for v in r] for r in rows[2:] if r])
    return {n: data[:, i] for i, n in enumerate(names)}

r, eps, Tp = 0.005, 0.7, 1173.15
A = 4 * math.pi * r**2
Q_exp = eps * A * SIG * (Tp**4 - T_inf**4)
out = ['# Baseline on unmodified FDS: cell-size sweep', '',
       f'Sphere r = 5 mm, emissivity 0.7, surface held at 900 C; black floor and surroundings at 20 C; no convection; transparent gas.',
       f'Expected net radiative loss of the sphere: eps*A*sigma*(Tp^4 - Tinf^4) = {Q_exp:.2f} W.',
       'Particle optical depth of its own cell: tau = (A/4)*eps/V * dx = 0.25*A*eps/dx^2 (FDS treats the particle as an absorbing medium filling the cell).', '',
       '| Cell size | tau | Particle loss (W) | vs expected | Floor gain (W) | Floor / particle | Expected floor / particle (finite floor) |',
       '|---|---|---|---|---|---|---|']
dxs, ratios = [], []
for dx_cm in (1, 2, 5):
    dx = dx_cm / 100
    d = read_fds_csv(f'{R}/hot_sphere_dx{dx_cm}cm_devc.csv')
    m = d['Time'] > 0.5
    Qp = -1000 * d['Q_part_rad'][m].mean()
    Qf = 1000 * d['Q_floor_rad'][m].mean()
    tau = 0.25 * A * eps / dx**2
    h = dx / 2
    exp_ratio = 0.5 * (1 - h / math.sqrt(h**2 + 0.5**2))
    out.append(f'| {dx_cm} cm | {tau:.3f} | {Qp:.2f} | {100*(Qp/Q_exp-1):+.1f}% | {Qf:.2f} | {Qf/Qp:.3f} | {exp_ratio:.3f} |')
    dxs.append(dx_cm); ratios.append(Qp / Q_exp)

rho, c, eps_s = 7850., 460., 0.8
m_c = rho * 4/3 * math.pi * r**3 * c
d = read_fds_csv(f'{R}/steel_sphere_cooling_dx5cm_devc.csv')
t = d['Time']; T_fds = d['T_sphere'] + 273.15
T_an = np.empty_like(t); T_an[0] = 1173.15
f = lambda T: -eps_s * A * SIG * (T**4 - T_inf**4) / m_c
for i in range(1, len(t)):
    dt = t[i] - t[i-1]; T = T_an[i-1]
    k1 = f(T); k2 = f(T + 0.5*dt*k1); k3 = f(T + 0.5*dt*k2); k4 = f(T + dt*k3)
    T_an[i] = T + dt * (k1 + 2*k2 + 2*k3 + k4) / 6
Qf_ratio = np.nan
m = (d['Q_part_rad'] < 0) & (t > 1)
if m.any(): Qf_ratio = np.mean(d['Q_floor_rad'][m] / -d['Q_part_rad'][m])
out += ['', '## Steel sphere cooling on the cold floor, 5 cm cells (radiation only)', '',
        f'm c = {m_c:.3f} J/K; lumped analytical solution m c dT/dt = -eps A sigma (T^4 - Tinf^4).',
        f'At 60 s: FDS {T_fds[np.argmin(abs(t-60))]-273.15:.1f} C, analytical {T_an[np.argmin(abs(t-60))]-273.15:.1f} C.',
        f'At 120 s: FDS {T_fds[-1]-273.15:.1f} C, analytical {T_an[-1]-273.15:.1f} C. Max difference {np.max(abs(T_fds-T_an)):.1f} K.',
        f'Average floor gain / particle loss: {Qf_ratio:.3f}.',
        'With no conduction path, the floor has no effect on how fast the particle cools beyond radiation.']
fig, ax = plt.subplots(1, 2, figsize=(10, 4))
ax[0].plot(dxs, ratios, 'o-'); ax[0].axhline(1, color='k', lw=0.8, ls='--')
ax[0].set_xlabel('Cell size (cm)'); ax[0].set_ylabel('FDS particle loss / expected'); ax[0].set_title('Resting 900 C sphere, r = 5 mm'); ax[0].grid(alpha=0.3)
ax[1].plot(t, T_fds - 273.15, label='FDS, 5 cm cells'); ax[1].plot(t, T_an - 273.15, '--', label='Analytical (radiation only)')
ax[1].set_xlabel('Time (s)'); ax[1].set_ylabel('Sphere temperature (C)'); ax[1].legend(); ax[1].grid(alpha=0.3); ax[1].set_title('Steel sphere cooling')
fig.tight_layout(); fig.savefig(f'{R}/baseline_dx_sweep.png', dpi=150)
open(f'{R}/summary_dx.md', 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
