"""FDS replica of Wessies and Ezekoye (2022), Fig. 13: Inconel 625 cylinder (D 19 mm, H 10 mm) at ~880 C placed on
calcium silicate (CS), 304 stainless steel (SS) or aluminium (Al), cooled by an impinging jet.
FDS has no upright-disc particle, so the cylinder is a CARTESIAN particle whose two faces (2LW) equal the cylinder's exposed
area (top + side, 8.80 cm2) and whose mass equals the cylinder's. Its footprint LW (4.40 cm2) is larger than the real bottom
face (2.84 cm2), so HEAT_TRANSFER_COEFFICIENT_SOLID is scaled by 2.84/4.40 to give the same contact conductance.
Convection: constant h from the authors' correlation Nu_D = 2.3936 Re^0.2937, with air conductivity at a mean film temperature."""
import math
D, H = 0.019, 0.010; a = D/2
A_exp = math.pi*a**2 + math.pi*D*H; A_c = math.pi*a**2
L = math.sqrt(A_exp/2); t_half = A_c*H/(2*L*L)
scale = A_c/(L*L)
cases = {'CS': dict(Re=5900., T0=880., matl="&MATL ID='SUBSTRATE', DENSITY=641., CONDUCTIVITY=0.069, SPECIFIC_HEAT=1.0, EMISSIVITY=0.9 /", k_film=0.044),
         'SS': dict(Re=4500., T0=885., matl="&MATL ID='SUBSTRATE', DENSITY=7900., CONDUCTIVITY=14.9, SPECIFIC_HEAT=0.477, EMISSIVITY=0.3 /", k_film=0.042),
         'Al': dict(Re=4500., T0=872., matl="&MATL ID='SUBSTRATE', DENSITY=2702., CONDUCTIVITY=237., SPECIFIC_HEAT=0.903, EMISSIVITY=0.1 /", k_film=0.041)}
import sys
hc = float(sys.argv[1]) if len(sys.argv) > 1 else 528.
for sub, c in cases.items():
    h = 2.3936*c['Re']**0.2937*c['k_film']/D
    for tag, hs in [('contact', hc*scale), ('nocontact', 0.)]:
        chid = f'wessies_{sub}_{tag}'
        hs_line = f'HEAT_TRANSFER_COEFFICIENT_SOLID={hs:.1f}, ' if hs > 0 else ''
        s = f"""&HEAD CHID='{chid}', TITLE='Inconel cylinder at {c["T0"]:.0f} C on {sub}, Wessies and Ezekoye (2022) Fig. 13, h_c={hc if hs>0 else 0:.0f} W/m2/K' /

&MESH IJK=8,8,3, XB=0.0,0.192,0.0,0.192,0.0,0.18 /
&TIME T_END=60. /
&MISC NOISE=F /

Air flow to keep the gas around the particle at ambient. Convection on the particle is set by its HEAT_TRANSFER_COEFFICIENT.
&SURF ID='INFLOW', VEL=-1.0 /
&VENT MB='XMIN', SURF_ID='INFLOW' /
&VENT MB='XMAX', SURF_ID='OPEN' /
&VENT MB='YMIN', SURF_ID='OPEN' /
&VENT MB='YMAX', SURF_ID='OPEN' /
&VENT MB='ZMAX', SURF_ID='OPEN' /

Substrate 25.4 mm thick, insulated below. Convection on the substrate is neglected, as in the authors' data reduction.
{c['matl']}
&SURF ID='SUBSTRATE', MATL_ID='SUBSTRATE', THICKNESS=0.0254, BACKING='INSULATED', TMP_INNER=20., HEAT_TRANSFER_COEFFICIENT=0. /
&VENT MB='ZMIN', SURF_ID='SUBSTRATE' /

Inconel 625: Special Metals (2013) data sheet; emissivity of the coating 0.95 (Wessies and Ezekoye 2022).
&RAMP ID='cp_in', T=21., F=0.410 /
&RAMP ID='cp_in', T=93., F=0.427 /
&RAMP ID='cp_in', T=204., F=0.456 /
&RAMP ID='cp_in', T=316., F=0.481 /
&RAMP ID='cp_in', T=427., F=0.511 /
&RAMP ID='cp_in', T=538., F=0.536 /
&RAMP ID='cp_in', T=649., F=0.565 /
&RAMP ID='cp_in', T=760., F=0.590 /
&RAMP ID='cp_in', T=871., F=0.620 /
&RAMP ID='cp_in', T=982., F=0.645 /
&RAMP ID='k_in', T=21., F=9.8 /
&RAMP ID='k_in', T=538., F=17.5 /
&RAMP ID='k_in', T=982., F=25.2 /
&MATL ID='INCONEL', DENSITY=8440., SPECIFIC_HEAT_RAMP='cp_in', CONDUCTIVITY_RAMP='k_in', EMISSIVITY=0.95 /
&SURF ID='CYLINDER', MATL_ID='INCONEL', THICKNESS={t_half:.5f}, LENGTH={L:.5f}, WIDTH={L:.5f}, GEOMETRY='CARTESIAN',
      TMP_INNER={c['T0']:.1f}, HEAT_TRANSFER_COEFFICIENT={h:.1f} /
&PART ID='cylinder', SURF_ID='CYLINDER', {hs_line}ADHERE_TO_SOLID=1, HORIZONTAL_VELOCITY=0., VERTICAL_VELOCITY=0., SAMPLING_FACTOR=1 /
&INIT ID='cylinder', PART_ID='cylinder', XYZ=0.084,0.084,0.004, N_PARTICLES=1 /

&DEVC ID='T_cylinder', QUANTITY='WALL TEMPERATURE', INIT_ID='cylinder', TIME_AVERAGED=.FALSE. /
&DEVC ID='T_substrate', QUANTITY='WALL TEMPERATURE', XYZ=0.084,0.084,0.0, IOR=3, TIME_AVERAGED=.FALSE. /
&DEVC ID='CPUA_substrate', QUANTITY='CPUA', PART_ID='cylinder', XYZ=0.084,0.084,0.0, IOR=3, TIME_AVERAGED=.FALSE. /

&TAIL /
"""
        open(f'{chid}.fds', 'w').write(s)
rc = open('wessies_SS_nocontact.fds').read()
rc = rc.replace("CHID='wessies_SS_nocontact'", "CHID='wessies_radcheck'").replace("TITLE='Inconel", "TITLE='Radiation only check: Inconel")
rc = rc.replace("&SURF ID='SUBSTRATE', MATL_ID='SUBSTRATE', THICKNESS=0.0254, BACKING='INSULATED', TMP_INNER=20., HEAT_TRANSFER_COEFFICIENT=0. /",
                "&SURF ID='SUBSTRATE', TMP_FRONT=20., TAU_T=0., EMISSIVITY=1.0, HEAT_TRANSFER_COEFFICIENT=0. /")
import re
rc = re.sub(r"HEAT_TRANSFER_COEFFICIENT=[0-9.]+ /\n&PART", "HEAT_TRANSFER_COEFFICIENT=0. /\n&PART", rc)
open('wessies_radcheck.fds','w').write(rc)
print(f'L = {L*1000:.2f} mm, half-thickness = {t_half*1000:.3f} mm, contact scale = {scale:.4f}')
for sub, c in cases.items(): print(sub, 'h =', round(2.3936*c['Re']**0.2937*c['k_film']/D, 1))
