from PIL import Image; import numpy as np, json, sys
im=np.array(Image.open('img8-001.png').convert('RGB')).astype(int)
r,g,b=im[...,0],im[...,1],im[...,2]
X0,X1,Y0,Y1=116,827,539,8
t=lambda px:(px-X0)/(X1-X0)*60; T=lambda py:(Y0-py)/(Y0-Y1)*1000
masks={'CS':(r+g+b<240)&(np.abs(r-g)<40)&(np.abs(g-b)<40),
       'SS':(g>r+25)&(g>b+10)&(g<200)&(r<140)&(b<160),
       'Al':(b>200)&(r<200)&(g>150)&(b>r+40)}
out={}
for name,m in masks.items():
    m=m.copy(); m[:,:X0+4]=False; m[:,X1-3:]=False; m[:Y1+4,:]=False; m[Y0-3:,:]=False; m[:170,640:]=False
    cols={}
    for x in range(X0+4,X1-3):
        ys=np.where(m[:,x])[0]
        if len(ys)==0: continue
        runs=[]; s=ys[0]; p=ys[0]
        for y in ys[1:]:
            if y>p+1: runs.append((s+p)/2); s=y
            p=y
        runs.append((s+p)/2); cols[x]=runs
    xs=sorted(cols)[::-1]; solid={}; dotted={}; ps=None; pd=None
    for x in xs:
        runs=sorted(cols[x])
        if ps is None: ps=runs[0]
        cand=[y for y in runs if abs(y-ps)<=6]
        if cand: ps=min(cand,key=lambda y:abs(y-ps)); solid[x]=ps
        rest=[y for y in runs if abs(y-ps)>3]
        if pd is None:
            below=[y for y in rest if y>ps+8]
            if below: pd=below[0]; dotted[x]=pd
        else:
            cd=[y for y in rest if abs(y-pd)<=8]
            if cd: pd=min(cd,key=lambda y:abs(y-pd)); dotted[x]=pd
    out[name]={'solid':[(t(x),T(y)) for x,y in sorted(solid.items())],'dotted':[(t(x),T(y)) for x,y in sorted(dotted.items())]}
    for k in ('solid','dotted'):
        d=out[name][k]; print(name,k,len(d), [ (round(a,1),round(c,1)) for a,c in (d[0],d[len(d)//2],d[-1])] if d else None)
json.dump(out,open('fig13_digitized.json','w'))
# overlay for checking
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(7,5)); ax.imshow(Image.open('img8-001.png'),extent=(t(0),t(im.shape[1]),T(im.shape[0]),T(0)),aspect='auto')
for name,c in [('CS','r'),('SS','m'),('Al','y')]:
    for k,ls in [('solid','-'),('dotted','--')]:
        d=np.array(out[name][k]);
        if len(d): ax.plot(d[:,0],d[:,1],ls,color=c,lw=0.8)
ax.set_xlim(-2,62); ax.set_ylim(0,1000); fig.savefig('fig13_check.png',dpi=110)
