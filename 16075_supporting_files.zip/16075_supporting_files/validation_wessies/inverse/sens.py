import wessies_inverse as w, numpy as np
from scipy.optimize import minimize_scalar
import json
out={}
for sub in ['SS','Al']:
    for hm in [0.8,1.0,1.2]:
        w.HMULT=hm
        r=minimize_scalar(lambda lh: w.rms(sub,10**lh,w.RE_LOW[sub],'solid'),bounds=(1.5,4),method='bounded',options={'xatol':0.01})
        hc=10**r.x; hi=w.rms(sub,hc,w.RE_HIGH,'dotted')
        out[f'{sub}_{hm}']=(hc,r.fun,hi); print(sub,hm,round(hc),round(r.fun,2),round(hi,2),flush=True)
    w.HMULT=1.0
w.FILM=False
for sub in ['SS']:
    r=minimize_scalar(lambda lh: w.rms(sub,10**lh,w.RE_LOW[sub],'solid'),bounds=(1.5,4),method='bounded',options={'xatol':0.01})
    print(sub,'room-temperature air k',round(10**r.x),round(r.fun,2),flush=True)
json.dump(out,open('sens.json','w'))
