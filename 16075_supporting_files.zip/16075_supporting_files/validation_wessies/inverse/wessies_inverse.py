"""Inverse analysis of Wessies and Ezekoye (2022), J. Thermal Sci. Eng. Appl. 14:011009, Fig. 13.
Inconel 625 cylinder (D 19 mm, H 10 mm, emissivity 0.95) at ~880 C placed flat on calcium silicate (CS), 304 stainless
steel (SS) or aluminium (Al), cooled by an impinging jet. Convection from the authors' bedded naphthalene correlation,
Nu_D = 2.3936 Re^0.2937 (thesis, Sec. 4.3.2). Radiation from the top and sides to ambient. Conduction from the bottom face
through a contact conductance h_c into the substrate, solved as 2-D axisymmetric transient conduction (r, z).
The fitted h_c is an all-mode conductance across the interface (gas-gap conduction, solid contact, and gap radiation)."""
import json, math, sys
import numpy as np
from scipy.optimize import minimize_scalar
SIG = 5.670374e-8; TINF = 293.15
D, H = 0.019, 0.010; a = D/2
A_exp = math.pi*a**2 + math.pi*D*H          # top + side (m2)
A_c = math.pi*a**2                          # bottom face (m2)
m = 8440.*math.pi*a**2*H                    # Special Metals (2013): 8.44 g/cm3
cpT = np.array([[21,410],[93,427],[204,456],[316,481],[427,511],[538,536],[649,565],[760,590],[871,620],[982,645]])  # Special Metals (2013)
cp = lambda T: np.interp(T-273.15, cpT[:,0], cpT[:,1])
KAIR = np.array([[300,.0263],[350,.0300],[400,.0338],[450,.0373],[500,.0407],[550,.0439],[600,.0469],[650,.0497],[700,.0524],[750,.0549],[800,.0573]])  # Incropera Table A.4
FILM = True
HMULT = 1.0
T0_HIGH = {'CS': 880., 'SS': 885., 'Al': 905.}   # read from Fig. 13 at t = 0 (dotted curves)
def h_conv(Re, T=None):
    k_air = np.interp(0.5*(T+TINF), KAIR[:,0], KAIR[:,1]) if (FILM and T is not None) else 0.0263
    return HMULT*2.3936*Re**0.2937*k_air/D
SUB = {'CS': dict(k=0.069, rho=641., c=1000., eps=0.9),     # rho from the thesis; k*rho*c gives the stated effusivity 210
       'SS': dict(k=14.9, rho=7900., c=477., eps=0.3),      # Incropera Table A.1, AISI 304, 300 K (effusivity 7490)
       'Al': dict(k=237., rho=2702., c=903., eps=0.1)}      # Incropera Table A.1, pure Al, 300 K (effusivity 24000)
def simulate(sub, hc, Re, T0, t_end=60., dr=0.5e-3, dz=0.5e-3, Rmax=0.0762, Z=0.0254, out_t=None):
    p = SUB[sub]; alpha = p['k']/(p['rho']*p['c'])
    nr, nz = int(round(Rmax/dr)), int(round(Z/dz))
    rc = (np.arange(nr)+0.5)*dr                                       # cell centres
    rf = np.arange(nr+1)*dr                                           # faces
    vol = np.pi*(rf[1:]**2-rf[:-1]**2)*dz                             # cell volumes per z-layer
    Ar = 2*np.pi*rf[1:-1]*dz                                          # radial face areas
    Az = np.pi*(rf[1:]**2-rf[:-1]**2)                                 # axial face areas
    contact = rc < a                                                  # top cells under the cylinder
    Ac_cells = Az*contact
    dt = 0.2*min(dr, dz)**2/alpha; dt = min(dt, 0.02)
    n = int(math.ceil(t_end/dt)); dt = t_end/n
    Ts = np.full((nz, nr), TINF); T = T0
    times = [0.]; temps = [T0]; hcv = h_conv(Re)
    C = p['rho']*p['c']*vol
    for i in range(n):
        # interface: half-cell conduction in series with hc
        Ufront = 1./(1./hc + dz/(2*p['k'])) if hc > 0 else 0.
        qc = Ufront*(T - Ts[0])*Ac_cells                              # W into each top cell
        Q_cond = qc.sum()
        dE = np.zeros_like(Ts)
        fr = p['k']*Ar*(Ts[:, 1:]-Ts[:, :-1])/dr                      # radial flux (W), positive outward means negative
        dE[:, :-1] += fr; dE[:, 1:] -= fr
        fz = p['k']*Az*(Ts[1:, :]-Ts[:-1, :])/dz
        dE[:-1, :] += fz; dE[1:, :] -= fz
        dE[0] += qc
        Ts = Ts + dt*dE/C
        Qloss = SIG*0.95*A_exp*(T**4-TINF**4) + h_conv(Re, T)*A_exp*(T-TINF) + Q_cond
        T = T - dt*Qloss/(m*cp(T))
        if (i+1) % max(1, int(0.25/dt)) == 0: times.append((i+1)*dt); temps.append(T)
    return np.array(times), np.array(temps)-273.15
def data(sub, kind):
    d = np.array(json.load(open('fig13_digitized.json'))[sub][kind]); return d[:, 0], d[:, 1]
RE_LOW = {'CS': 5900., 'SS': 4500., 'Al': 4500.}; RE_HIGH = 17300.
def rms(sub, hc, Re, kind):
    td, Td = data(sub, kind); T0 = np.interp(0.5, td, Td) if td[0] < 1 else T0_HIGH[sub]
    t, T = simulate(sub, hc, Re, T0+273.15)
    m_ = (td >= 2) & (td <= 60)
    return math.sqrt(np.mean((np.interp(td[m_], t, T)-Td[m_])**2))
if __name__ == '__main__':
    res = {}
    for sub in ['SS', 'Al', 'CS']:
        f = lambda lh: rms(sub, 10**lh, RE_LOW[sub], 'solid')
        r = minimize_scalar(f, bounds=(0.5, 5.0), method='bounded', options={'xatol': 0.01})
        hc = 10**r.x
        res[sub] = dict(hc=hc, rms_fit=r.fun, rms_high=rms(sub, hc, RE_HIGH, 'dotted'),
                        rms_none=rms(sub, 0., RE_LOW[sub], 'solid'), rms_perfect=rms(sub, 1e5, RE_LOW[sub], 'solid'))
        print(sub, {k: round(v, 2) for k, v in res[sub].items()}, flush=True)
    json.dump(res, open('wessies_fit.json', 'w'), indent=1)
