import sys, csv
import numpy as np
from scipy.integrate import dblquad
R = sys.argv[1]
def read(p):
    rows = list(csv.reader(open(p))); names = [n.strip() for n in rows[1]]
    d = np.array([[float(v) for v in r] for r in rows[2:] if r]); return {n: d[:, i] for i, n in enumerate(names)}
F = lambda h, a: dblquad(lambda y, x: h/(4*np.pi*(x*x+y*y+h*h)**1.5), -a, a, -a, a)[0]
out = ['# Where the radiation of a resting particle lands (unmodified FDS radiation solver)', '',
       'Sphere r = 5 mm, surface 900 C, emissivity 0.7, resting on a black floor at 20 C; transparent gas; 104 angles.', '',
       '| Cell size | Floor gain (W) | Gain in the cell beneath (W) | Share beneath, FDS | Share beneath, exact view factor | Share if emitted from the cell-centre height |',
       '|---|---|---|---|---|---|']
for dx in (5, 10):
    d = read(f'{R}/rad_beneath_dx{dx}cm_devc.csv'); m = d['Time'] > 0.5
    Qf = 1000*d['Q_floor_rad'][m].mean(); qb = 1000*d['q_beneath'][m].mean()*(dx/100)**2
    out.append(f'| {dx} cm | {Qf:.2f} | {qb:.2f} | {qb/Qf:.3f} | {F(0.005, dx/200)/0.5:.3f} | {F(dx/200, dx/200)/0.5:.3f} |')
open(f'{R}/summary_rad_beneath.md', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
