# Where the radiation of a resting particle lands (unmodified FDS radiation solver)

Sphere r = 5 mm, surface 900 C, emissivity 0.7, resting on a black floor at 20 C; transparent gas; 104 angles.

| Cell size | Floor gain (W) | Gain in the cell beneath (W) | Share beneath, FDS | Share beneath, exact view factor | Share if emitted from the cell-centre height |
|---|---|---|---|---|---|
| 5 cm | 11.00 | 3.87 | 0.352 | 0.823 | 0.333 |
| 10 cm | 9.89 | 3.91 | 0.396 | 0.910 | 0.333 |
