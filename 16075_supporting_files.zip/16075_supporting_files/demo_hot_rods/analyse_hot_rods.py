"""hot_rods with contact conduction to the 800 C floor: rod mass and mean rod temperature for h_s = 0, 50, 200 W/m2/K."""
import sys, csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R = sys.argv[1]
def read(path):
    rows = list(csv.reader(open(path)))
    names = [n.strip() for n in rows[1]]
    data = np.array([[float(v) for v in r] for r in rows[2:] if r])
    return {n: data[:, i] for i, n in enumerate(names)}
out = ['# hot_rods (WUI verification case) with contact conduction between the rods and the 800 C floor', '',
       '4000 wooden rods (r = 2-3 mm, L = 20 mm) are poured onto a floor held at 800 C over 10 s and burn.', '',
       '| h_s (W/m2/K) | Time for rod mass to fall to 50% of peak (s) | Mean rod temperature at 20 s (C) | Wall time (s) |', '|---|---|---|---|']
times = {}
for line in open(f'{R}/timing.txt'):
    k, v = line.split(); times[k] = v
fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
for hs in (0, 50, 200):
    d = read(f'{R}/hot_rods_hs{hs}_devc.csv'); t = d['Time']; M = d['Mass 2']
    i0 = np.argmax(M); half = np.nan
    j = np.where((t > t[i0]) & (M < 0.5*M[i0]))[0]
    if len(j): half = t[j[0]]
    Tm = d['T_rods']
    out.append(f'| {hs} | {half:.1f} | {np.interp(20,t,Tm):.0f} | {times.get(f"hs{hs}","?")} |')
    ax[0].plot(t, M, label=f'h_s = {hs}'); ax[1].plot(t, Tm, label=f'h_s = {hs}')
ax[0].set_xlabel('Time (s)'); ax[0].set_ylabel('Rod mass on the floor (kg)'); ax[0].legend(); ax[0].grid(alpha=0.3)
ax[1].set_xlabel('Time (s)'); ax[1].set_ylabel('Mean rod temperature (C)'); ax[1].legend(); ax[1].grid(alpha=0.3)
fig.suptitle('hot_rods: effect of contact conduction with the 800 C floor'); fig.tight_layout()
fig.savefig(f'{R}/hot_rods_contact.png', dpi=150)
open(f'{R}/summary_hot_rods.md', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
