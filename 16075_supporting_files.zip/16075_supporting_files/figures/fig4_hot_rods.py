import sys, os, csv, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
R = sys.argv[1]; OUT = sys.argv[2]; R0 = sys.argv[3]
INK, INK2, AXIS, GRID, SURF = '#0b0b0b', '#52514e', '#c3c2b7', '#e9e8e3', '#fcfcfb'
COL = {0: INK, 50: '#2a78d6', 200: '#eb6834'}
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': AXIS, 'axes.labelcolor': INK2, 'xtick.color': INK2, 'ytick.color': INK2,
    'axes.titlecolor': INK, 'axes.titlesize': 9.5, 'axes.titleweight': 'bold', 'figure.facecolor': SURF, 'axes.facecolor': SURF,
    'legend.frameon': False, 'legend.labelcolor': INK2, 'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.6, 'lines.linewidth': 1.6})
def read(p):
    rows = list(csv.reader(open(p))); n = [x.strip() for x in rows[1]]; d = np.array([[float(v) for v in r] for r in rows[2:] if r]); return {k: d[:, i] for i, k in enumerate(n)}
fig, axs = plt.subplots(1, 2, figsize=(8.2, 3.3), constrained_layout=True)
for hs in (0, 50, 200):
    d = read(f'{R}/hot_rods_hs{hs}_devc.csv'); axs[0].plot(d['Time'], d['Mass 2'], color=COL[hs], label=f'h_s = {hs} W/m²K')
    if hs > 0:
        u = np.array([[float(v) for v in x.split(',')] for x in open(f'{R0}/nolimit_hs{hs}.txt').read().split()])
        axs[0].plot(u[:, 0], u[:, 1], '--', color=COL[hs], lw=1.2, label=f'h_s = {hs}, no pile limit')
axs[0].set_title('Mass of rods on the floor', loc='left'); axs[0].set_xlabel('Time (s)'); axs[0].set_ylabel('Mass (kg)'); axs[0].set_xlim(0, 300); axs[0].legend(fontsize=7.5)
for hs in (0, 50, 200):
    d = read(f'{R}/hot_rods_hs{hs}_devc.csv'); axs[1].plot(d['Time'], d['T_rods'], color=COL[hs], label=f'h_s = {hs} W/m²K')
axs[1].set_title('Mean rod temperature', loc='left'); axs[1].set_xlabel('Time (s)'); axs[1].set_ylabel('Temperature (°C)'); axs[1].set_xlim(0, 300); axs[1].legend(fontsize=7.5)
fig.suptitle('hot_rods (FDS Verification/WUI): wooden rods poured onto a floor held at 800 °C, with contact conduction', color=INK, fontsize=9.5, x=0.01, ha='left')
fig.savefig(os.path.join(OUT, 'fig4_hot_rods.png'), dpi=200)
