"""Verification figures for Issue #16075 (particle-surface contact heat transfer)."""
import sys, os, math, csv
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.special import erfcx
RES = sys.argv[1]; OUT = sys.argv[2]; EXACT = sys.argv[3]
src = open(EXACT).read().split('cases = [')[0]; sys.argv = [sys.argv[0], OUT]; exec(src)   # theta_surface(), read()
INK, INK2, MUTED, AXIS, GRID, SURF = '#0b0b0b', '#52514e', '#898781', '#c3c2b7', '#e9e8e3', '#fcfcfb'
BLUE, ORANGE = '#2a78d6', '#eb6834'
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': AXIS, 'axes.labelcolor': INK2, 'xtick.color': INK2, 'ytick.color': INK2,
                     'axes.titlecolor': INK, 'axes.titlesize': 9.5, 'axes.titleweight': 'bold', 'figure.facecolor': SURF, 'axes.facecolor': SURF,
                     'legend.frameon': False, 'legend.labelcolor': INK2, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.6, 'lines.linewidth': 1.6})
def p(*a): return os.path.join(RES, *a)
def fds_markers(ax, t, y, n=25, **kw):
    idx = np.unique(np.linspace(0, len(t)-1, n).astype(int))
    ax.plot(t[idx], y[idx], 'o', ms=4.5, mfc=BLUE, mec=SURF, mew=0.8, color=BLUE, **kw)
# Figure 1: particle on a fixed-temperature floor, four cases
cases = [('Steel sphere, r = 5 mm, on a 20 °C floor', p('diagnostics', 'contact_sphere_cooling_inst_devc.csv'), 'sphere', 0.005, 0.25, 900., 20.),
         ('Steel cylinder lying flat, r = 3.2 mm, L = 38 mm', p('exact', 'contact_cylinder_cooling_inst_devc.csv'), 'cylinder', 0.0032, 1/math.pi, 900., 20.),
         ('Steel plate, 6 × 20 × 20 mm, on a 20 °C floor', p('exact', 'contact_plate_cooling_inst_devc.csv'), 'plate', 0.003, 0.5, 900., 20.),
         ('Cold steel sphere on a 600 °C floor', p('general', 'contact_hot_floor_devc.csv'), 'sphere', 0.005, 0.25, 20., 600.)]
fig, axs = plt.subplots(2, 2, figsize=(8.2, 5.8), constrained_layout=True)
for ax, (title, f, shape, L, ratio, Ti, Tw) in zip(axs.flat, cases):
    d = read(f); t, T = d['Time'], d['T_sphere']; th, Bi = theta_surface(shape, L, 500.*ratio, t); Tex = Tw + (Ti-Tw)*th
    ax.plot(t, Tex, '-', color=INK, lw=1.4, label='Exact')
    fds_markers(ax, t, T, label='FDS')
    e = np.max(np.abs(T[t > 0]-Tex[t > 0]))
    ax.set_title(title, loc='left'); ax.set_xlabel('Time (s)'); ax.set_ylabel('Particle surface temperature (°C)')
    ax.text(0.97, 0.5 if Ti > Tw else 0.12, f'max difference {e:.2f} K\n({100*e/abs(Ti-Tw):.2f}% of the change)', transform=ax.transAxes, ha='right', color=INK2, fontsize=8)
    ax.set_xlim(0, 200); ax.legend(loc='upper right' if Ti > Tw else 'center right')
fig.suptitle('Contact conduction, h_s = 500 W/m²K, radiation and convection off: FDS vs exact conduction solution', color=INK, fontsize=10, x=0.01, ha='left')
fig.savefig(os.path.join(OUT, 'fig1_particle_on_fixed_floor.png'), dpi=200); plt.close(fig)
# Figure 2: energy budget
fig, axs = plt.subplots(1, 2, figsize=(8.2, 3.2), constrained_layout=True)
d1 = read(p('contact_energy_budget_devc.csv')); d12 = read(p('general', 'contact_three_spheres_devc.csv'))
sets = [('One 900 °C sphere on a thick slab', d1['Time'], -d1['H_sphere'], d1['H_floor_cell']),
        ('Three spheres (900, 700, 500 °C) in one floor cell', d12['Time'], -(d12['H_900']+d12['H_700']+d12['H_500']), d12['H_floor_cell'])]
for ax, (title, t, lost, gain) in zip(axs, sets):
    ax.plot(t, lost, '-', color=INK, lw=1.4, label='Lost by the particles')
    idx = np.unique(np.linspace(0, len(t)-1, 25).astype(int))
    ax.plot(t[idx], gain[idx], 'o', ms=4.5, mfc=BLUE, mec=SURF, mew=0.8, label='Gained by the floor cell')
    imb = np.max(np.abs(gain-lost))/lost[-1]
    ax.set_title(title, loc='left'); ax.set_xlabel('Time (s)'); ax.set_ylabel('Energy (kJ)'); ax.legend(loc='lower right')
    ax.text(0.97, 0.27, f'largest imbalance {100*imb:.2f}% of the transfer', transform=ax.transAxes, ha='right', color=INK2, fontsize=8)
fig.savefig(os.path.join(OUT, 'fig2_energy_budget.png'), dpi=200); plt.close(fig)
# Figure 3: slab heating vs Carslaw and Jaeger
k, rs, cs = 0.2, 500., 1500.; a = k/(rs*cs); he = 500.*math.pi*0.005**2/0.02**2
fig, axs = plt.subplots(1, 2, figsize=(8.2, 3.3), constrained_layout=True)
dd = read(p('contact_slab_heating_devc.csv')); du = read(p('diagnostics', 'contact_slab_heating_uniform_devc.csv'))
Tcj = lambda t: 20+580*(1-erfcx(he*np.sqrt(a*np.maximum(t, 1e-12))/k))
tt = np.linspace(0, 60, 601); ax = axs[0]
ax.plot(tt, Tcj(tt), '-', color=INK, lw=1.4, label='Exact (Carslaw and Jaeger)')
idx = np.unique(np.linspace(0, len(dd['Time'])-1, 22).astype(int))
ax.plot(dd['Time'][idx], dd['T_floor_cell'][idx], 's', ms=4.5, mfc=ORANGE, mec=SURF, mew=0.8, label='FDS, default floor grid (16 cells)')
ax.plot(du['Time'][idx], du['T_floor_cell'][idx], 'o', ms=4.5, mfc=BLUE, mec=SURF, mew=0.8, label='FDS, uniform 0.125 mm grid (400 cells)')
ax.set_title('Floor surface temperature under the sphere', loc='left'); ax.set_xlabel('Time (s)'); ax.set_ylabel('Temperature (°C)')
ax.set_xlim(0, 60); ax.legend(loc='lower right', fontsize=8)
ax = axs[1]
for dset, col, lab in [(dd, ORANGE, 'Default floor grid'), (du, BLUE, 'Uniform 0.125 mm grid')]:
    m = dset['Time'] >= 1.
    ax.plot(dset['Time'][m], dset['T_floor_cell'][m]-Tcj(dset['Time'][m]), '-', color=col, lw=1.6, label=lab)
ax.axhline(0, color=AXIS, lw=0.8)
ax.set_title('FDS minus exact', loc='left'); ax.set_xlabel('Time (s)'); ax.set_ylabel('Difference (K)'); ax.set_xlim(0, 60); ax.legend(loc='lower right', fontsize=8)
fig.suptitle('Sphere held at 600 °C on a thick slab (k = 0.2 W/m/K), h_s = 500 W/m²K, heat spread over a 2 cm × 2 cm floor cell', color=INK, fontsize=9.5, x=0.01, ha='left')
fig.savefig(os.path.join(OUT, 'fig3_slab_heating.png'), dpi=200); plt.close(fig)
print('done')
