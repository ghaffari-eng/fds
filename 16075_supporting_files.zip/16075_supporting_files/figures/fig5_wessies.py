import sys, json, csv, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
R = sys.argv[1]; OUT = sys.argv[2]
INK, INK2, AXIS, GRID, SURF = '#0b0b0b', '#52514e', '#c3c2b7', '#e9e8e3', '#fcfcfb'
COL = {'CS': INK, 'SS': '#2a78d6', 'Al': '#eb6834'}
NAME = {'CS': 'Calcium silicate', 'SS': 'Stainless steel', 'Al': 'Aluminium'}
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': AXIS, 'axes.labelcolor': INK2, 'xtick.color': INK2, 'ytick.color': INK2,
    'axes.titlecolor': INK, 'axes.titlesize': 9.5, 'axes.titleweight': 'bold', 'figure.facecolor': SURF, 'axes.facecolor': SURF,
    'legend.frameon': False, 'legend.labelcolor': INK2, 'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.6, 'lines.linewidth': 1.6})
def read(p):
    rows = list(csv.reader(open(p))); n = [x.strip() for x in rows[1]]; d = np.array([[float(v) for v in r] for r in rows[2:] if r]); return {k: d[:, i] for i, k in enumerate(n)}
dig = json.load(open('fig13_digitized.json'))
fig, axs = plt.subplots(1, 3, figsize=(9.6, 3.4), constrained_layout=True, sharey=True)
for ax, sub in zip(axs, ['CS', 'SS', 'Al']):
    td, Td = np.array(dig[sub]['solid']).T
    idx = np.unique(np.linspace(0, len(td)-1, 16).astype(int))
    ax.plot(td[idx], Td[idx], 'o', ms=4.5, mfc=COL[sub], mec=SURF, mew=0.8, label='Measured')
    c = read(f'{R}/wessies_{sub}_contact651_devc.csv' if sub == 'Al' else f'{R}/wessies_{sub}_contact_devc.csv'); n = read(f'{R}/wessies_{sub}_nocontact_devc.csv')
    ax.plot(c['Time'], c['T_cylinder'], '-', color=COL[sub], label='FDS, contact on (h_c = %d)' % (651 if sub == 'Al' else 528))
    ax.plot(n['Time'], n['T_cylinder'], ':', color=COL[sub], lw=1.6, label='FDS, no contact')
    ax.set_title(NAME[sub], loc='left'); ax.set_xlabel('Time (s)'); ax.set_xlim(0, 60); ax.set_ylim(0, 1000)
    ax.legend(loc='lower left', fontsize=7.5)
axs[0].set_ylabel('Cylinder temperature (°C)')
fig.suptitle('Hot Inconel cylinder placed on three substrates (Wessies and Ezekoye 2022, Fig. 13, lower jet speed) vs FDS, h_c in W/m²K', color=INK, fontsize=9.5, x=0.01, ha='left')
fig.savefig(f'{OUT}/fig5_wessies_validation.png', dpi=200)
