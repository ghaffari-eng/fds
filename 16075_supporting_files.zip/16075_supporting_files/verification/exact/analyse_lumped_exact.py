"""Particle on a floor held at a fixed temperature: FDS surface temperature against the exact series solution of transient
conduction in a sphere, a long cylinder and a plate, with a uniform heat transfer coefficient h = h_s * (footprint / total area)
over the particle surface (Incropera et al., Fundamentals of Heat and Mass Transfer, Sec. 5.6, Eqs. 5.39-5.52).
Device output must be instantaneous (TIME_AVERAGED=.FALSE.)."""
import sys, csv, os, math
import numpy as np
from scipy.optimize import brentq
from scipy.special import j0, j1
R = sys.argv[1]
rho, c, k, h_s = 7850., 460., 45., 500.
alpha = k/(rho*c)
def read(p):
    rows = list(csv.reader(open(p))); names = [n.strip() for n in rows[1]]
    d = np.array([[float(v) for v in r] for r in rows[2:] if r]); return {n: d[:, i] for i, n in enumerate(names)}
def roots(f, n=40):
    z = []; a = 1e-9
    while len(z) < n:
        xs = np.linspace(a, a+math.pi, 2001); ys = [f(x) for x in xs]
        for i in range(len(xs)-1):
            if np.isfinite(ys[i]) and np.isfinite(ys[i+1]) and ys[i]*ys[i+1] < 0 and abs(ys[i]-ys[i+1]) < 10:
                z.append(brentq(f, xs[i], xs[i+1]))
        a += math.pi
    return np.array(sorted(set(np.round(z, 12))))[:n]
def theta_surface(shape, L, h, t):
    Bi = h*L/k; Fo = alpha*np.asarray(t)/L**2
    if shape == 'plate':
        z = roots(lambda x: x*math.tan(x)-Bi); C = 4*np.sin(z)/(2*z+np.sin(2*z)); X = np.cos(z)
    elif shape == 'cylinder':
        z = roots(lambda x: x*j1(x)/j0(x)-Bi); C = 2/z*j1(z)/(j0(z)**2+j1(z)**2); X = j0(z)
    else:
        z = roots(lambda x: 1-x/math.tan(x)-Bi); C = 4*(np.sin(z)-z*np.cos(z))/(2*z-np.sin(2*z)); X = np.sin(z)/z
    return np.sum(C[None, :]*np.exp(-np.outer(Fo, z**2))*X[None, :], axis=1), Bi
cases = [('V2', 'contact_sphere_cooling_inst', 'sphere', 0.005, 0.25, 900., 20.),
         ('V6a', 'contact_cylinder_cooling_inst', 'cylinder', 0.0032, 1/math.pi, 900., 20.),
         ('V6b', 'contact_plate_cooling_inst', 'plate', 0.003, 0.5, 900., 20.),
         ('V10', 'contact_hot_floor', 'sphere', 0.005, 0.25, 20., 600.)]
out = ['# Particle on a fixed-temperature floor: FDS against the exact conduction solution', '',
       '| Case | Shape | h over particle surface (W/m2/K) | Biot | Max difference (K) | % of the temperature change | Lumped model, max difference (K) |',
       '|---|---|---|---|---|---|---|']
for tag, chid, shape, L, ratio, Ti, Tw in cases:
    f = None
    for d_ in [R, os.path.join(R, '..', 'diagnostics'), os.path.join(R, '..', 'general')]:
        if os.path.exists(os.path.join(d_, chid+'_devc.csv')): f = os.path.join(d_, chid+'_devc.csv')
    if f is None: out.append(f'| {tag} | {shape} | | | no output | | |'); continue
    d = read(f); t, T = d['Time'], d['T_sphere']; h = h_s*ratio
    th, Bi = theta_surface(shape, L, h, t); Tex = Tw + (Ti-Tw)*th
    nv = {'sphere': 3, 'cylinder': 2, 'plate': 1}[shape]; tau = rho*c*L/(nv*h)
    Tl = Tw + (Ti-Tw)*np.exp(-t/tau)
    m = t > 0
    e = np.max(np.abs(T[m]-Tex[m])); el = np.max(np.abs(T[m]-Tl[m]))
    out.append(f'| {tag} | {shape} | {h:.2f} | {Bi:.4f} | {e:.3f} | {100*e/abs(Ti-Tw):.3f} | {el:.2f} |')
out += ['', 'Exact: series solution for the surface temperature (first 40 terms). Lumped: single exponential with tau = rho c L / (n h), n = 3, 2, 1.']
open(os.path.join(R, 'summary_lumped_exact.md'), 'w').write('\n'.join(out)+'\n'); print('\n'.join(out))
