"""General use: a hot floor heating a cold particle (heat flows both ways), and several particle classes in one floor cell."""
import sys, csv, os
import numpy as np
R = sys.argv[1]
def read(p):
    rows = list(csv.reader(open(p))); names = [n.strip() for n in rows[1]]
    d = np.array([[float(v) for v in r] for r in rows[2:] if r]); return {n: d[:, i] for i, n in enumerate(names)}
out = ['# General use', '']
f = f'{R}/contact_hot_floor_devc.csv'
if os.path.exists(f):
    d = read(f); t, T = d['Time'], d['T_sphere']; tau = 4*7850.*460.*0.005/(3*500.)
    e = np.abs(T-(600-580*np.exp(-t/tau)))
    out += ['## V10. Cold steel sphere (20 C) on a floor held at 600 C', '',
            f'tau = {tau:.2f} s; T at {t[-1]:.0f} s: FDS {T[-1]:.2f} C, exact {600-580*np.exp(-t[-1]/tau):.2f} C',
            f'Max difference from exact: {e.max():.2f} K ({100*e.max()/580:.2f}% of the 580 K rise) at t = {t[np.argmax(e)]:.1f} s', '']
else: out += ['## V10: no output (see job log)', '']
f = f'{R}/contact_three_spheres_devc.csv'
if os.path.exists(f):
    d = read(f); t = d['Time']; lost = -(d['H_900']+d['H_700']+d['H_500']); gain = d['H_floor_cell']
    out += ['## V12. Three particle classes (900, 700, 500 C) resting in one floor cell of a thick slab', '',
            f'Lost by the spheres: 900 C {-d["H_900"][-1]:.4f} kJ, 700 C {-d["H_700"][-1]:.4f} kJ, 500 C {-d["H_500"][-1]:.4f} kJ; total {lost[-1]:.4f} kJ',
            f'Gained by the floor cell: {gain[-1]:.4f} kJ; final imbalance {gain[-1]-lost[-1]:+.2e} kJ ({100*(gain[-1]-lost[-1])/lost[-1]:+.3f}%); '
            f'largest imbalance over the run {np.max(np.abs(gain-lost)):.2e} kJ = {100*np.max(np.abs(gain-lost))/lost[-1]:.3f}% of the energy transferred (same measure as V1)', '']
else: out += ['## V12: no output (see job log)', '']
open(f'{R}/summary_general.md', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
