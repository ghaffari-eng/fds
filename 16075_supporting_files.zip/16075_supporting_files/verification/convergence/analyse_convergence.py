"""Sphere and plate on a 20 C floor: error against the exact conduction solution as the particle wall grid and the time step are refined."""
import sys, os, csv
import numpy as np
here = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(here, '..', 'exact', 'analyse_lumped_exact.py')).read().split('cases = [')[0]
R = sys.argv[1]; sys.argv = [sys.argv[0], R]; exec(src)
levels = [('Base (default particle grid, DT = 0.05 s)', 0, os.path.join(R, '..', 'diagnostics', 'contact_sphere_cooling_inst_devc.csv'), os.path.join(R, '..', 'exact', 'contact_plate_cooling_inst_devc.csv')),
          ('CELL_SIZE_FACTOR = 0.5, DT = 0.025 s', 1, os.path.join(R, 'conv_sphere_l1_devc.csv'), os.path.join(R, 'conv_plate_l1_devc.csv')),
          ('CELL_SIZE_FACTOR = 0.25, DT = 0.0125 s', 2, os.path.join(R, 'conv_sphere_l2_devc.csv'), os.path.join(R, 'conv_plate_l2_devc.csv'))]
out = ['# Convergence: particle on a 20 C floor against the exact conduction solution', '',
       '| Refinement | Sphere: max difference (K) | Plate: max difference (K) |', '|---|---|---|']
for tag, lev, fs, fp in levels:
    row = [tag]
    for f, shape, L, ratio in [(fs, 'sphere', 0.005, 0.25), (fp, 'plate', 0.003, 0.5)]:
        if not os.path.exists(f): row.append('no output'); continue
        d = read(f); t, T = d['Time'], d['T_sphere']; th, Bi = theta_surface(shape, L, h_s*ratio, t); Tex = 20 + 880*th; m = t > 0
        row.append(f'{np.max(np.abs(T[m]-Tex[m])):.3f}')
    out.append('| ' + ' | '.join(row) + ' |')
open(os.path.join(R, 'summary_convergence.md'), 'w').write('\n'.join(out)+'\n'); print('\n'.join(out))
