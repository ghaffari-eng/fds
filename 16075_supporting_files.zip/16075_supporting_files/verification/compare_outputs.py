"""Compare FDS csv outputs (devc, hrr) from the master build and the branch build, column by column."""
import sys, csv, os
import numpy as np
base = sys.argv[1]; cases = sys.argv[2:]
def read(path):
    rows = list(csv.reader(open(path)))
    names = [n.strip() for n in rows[1]]
    data = np.array([[float(v) for v in r] for r in rows[2:] if r])
    return names, data
lines = ['| Case | File | Columns | Rows | Identical | Max abs difference | Max relative difference |', '|---|---|---|---|---|---|---|']
for c in cases:
    for kind in ('devc', 'hrr'):
        a = f'{base}/master/{c}_{kind}.csv'; b = f'{base}/branch/{c}_{kind}.csv'
        if not (os.path.exists(a) and os.path.exists(b)):
            lines.append(f'| {c} | {kind} | - | - | missing | - | - |'); continue
        na, da = read(a); nb, db = read(b)
        if na != nb or da.shape != db.shape:
            lines.append(f'| {c} | {kind} | {len(na)}/{len(nb)} | {da.shape[0]}/{db.shape[0]} | NO (shape) | - | - |'); continue
        diff = np.abs(da - db)
        scale = np.maximum(np.abs(da), 1e-30)
        same = bool(np.array_equal(da, db))
        lines.append(f'| {c} | {kind} | {len(na)} | {da.shape[0]} | {"yes" if same else "NO"} | {diff.max():.3e} | {(diff/scale).max():.3e} |')
print('\n'.join(lines))
open(f'{base}/backward_compatibility.md', 'w').write('# Backward compatibility: master 5569f0e vs branch, feature not used, 1 OpenMP thread\n\n' + '\n'.join(lines) + '\n')
