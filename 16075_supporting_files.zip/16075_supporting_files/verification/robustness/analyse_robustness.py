"""Robustness checks for contact heat transfer: wall-grid/time-step convergence, wall update interval, OpenMP, MPI, restart, GEOM."""
import sys, csv, math, os
import numpy as np
from scipy.special import erfcx
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R = sys.argv[1]; R0 = sys.argv[2]   # robustness results, and the V1-V3 results for reference
def read(path):
    rows = list(csv.reader(open(path)))
    names = [n.strip() for n in rows[1]]
    data = np.array([[float(v) for v in r] for r in rows[2:] if r])
    return {n: data[:, i] for i, n in enumerate(names)}
out = ['# Robustness checks', '']
r, A_c, h_s = 0.005, math.pi*0.005**2, 500.
m_c = 7850 * 4/3*math.pi*r**3 * 460

# V3 convergence
k, rho_s, c_s = 0.2, 500., 1500.; alpha = k/(rho_s*c_s); h_eff = h_s*A_c/0.02**2
out += ['## V3 slab heating: wall-grid (CELL_SIZE_FACTOR) and time-step convergence', '',
        '| Case | CELL_SIZE_FACTOR | DT (s) | T_s at 10 s (C) | T_s at 60 s (C) | Max difference from exact, 1-60 s (K) |', '|---|---|---|---|---|---|']
fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
for tag, csf, dt in [('csf100',1.0,0.02),('csf050',0.5,0.02),('csf025',0.25,0.02),('csf010',0.1,0.02),('csf010_dt005',0.1,0.005)]:
    f = f'{R}/contact_slab_heating_{tag}_devc.csv'
    if not os.path.exists(f): out.append(f'| {tag} | {csf} | {dt} | missing | | |'); continue
    d = read(f); t, Ts = d['Time'], d['T_floor_cell']
    Tan = 20 + 580*(1 - erfcx(h_eff*np.sqrt(alpha*t)/k)); m = t > 1
    out.append(f'| {tag} | {csf} | {dt} | {np.interp(10,t,Ts):.2f} | {Ts[-1]:.2f} | {np.max(np.abs(Ts[m]-Tan[m])):.2f} |')
    ax[0].plot(t, Ts - Tan, label=f'CSF {csf}, DT {dt}')
t = np.linspace(0.01, 60, 600)
out += ['', f'Exact at 10 s: {20+580*(1-erfcx(h_eff*np.sqrt(alpha*10)/k)):.2f} C; at 60 s: {20+580*(1-erfcx(h_eff*np.sqrt(alpha*60)/k)):.2f} C', '']
ax[0].set_xlabel('Time (s)'); ax[0].set_ylabel('FDS - exact (K)'); ax[0].set_title('V3: error vs wall grid and time step'); ax[0].legend(); ax[0].grid(alpha=0.3)

# V1 energy budget, wall update interval and OpenMP
out += ['## V1 energy budget: wall update interval and OpenMP threads', '', '| Case | Lost by sphere (kJ) | Gained by floor cell (kJ) | Final imbalance (kJ) | Largest imbalance (% of transfer) |', '|---|---|---|---|---|']
ref = None
for tag, f in [('WALL_INCREMENT=2 (default), 2 threads', f'{R0}/contact_energy_budget_devc.csv'),
               ('WALL_INCREMENT=1, 2 threads', f'{R}/contact_energy_budget_wi1_devc.csv'),
               ('WALL_INCREMENT=2, 4 threads', f'{R}/contact_energy_budget_omp4_devc.csv')]:
    if not os.path.exists(f): out.append(f'| {tag} | missing | | | |'); continue
    d = read(f); Hs, Hf = d['H_sphere'], d['H_floor_cell']; S = Hs + Hf
    out.append(f'| {tag} | {-Hs[-1]:.5f} | {Hf[-1]:.5f} | {S[-1]:+.2e} | {100*np.max(np.abs(S))/np.max(np.abs(Hs)):.3f} |')
    if 'threads' in tag and '2 threads' in tag and 'WALL_INCREMENT=2' in tag: ref = d
d4 = f'{R}/contact_energy_budget_omp4_devc.csv'
if ref is not None and os.path.exists(d4):
    d = read(d4); out += ['', f'2 threads vs 4 threads, sphere temperature: max difference {np.max(np.abs(d["T_sphere"]-ref["T_sphere"])):.2e} K', '']

# V2 variants: two meshes, restart, GEOM floor, against the single-mesh run and the exact solution
base = read(f'{R0}/contact_sphere_cooling_devc.csv')
tb, Tb = base['Time'], base['T_sphere']
Tex = lambda t: 20 + 880*np.exp(-t*h_s*A_c/m_c)
out += ['## V2 variants (sphere cooling on a 20 C floor)', '', '| Case | Max difference from single-mesh run (K) | Max difference from exact (K) |', '|---|---|---|']
out.append(f'| Single mesh (reference) | 0 | {np.max(np.abs(Tb-Tex(tb))):.2f} |')
for tag, f in [('Two meshes, particle in mesh 2', f'{R}/contact_sphere_cooling_2mesh_devc.csv'),
               ('Stopped at 100 s, restarted to 200 s', f'{R}/contact_restart_devc.csv'),
               ('GEOM (cut-cell) floor', f'{R}/contact_sphere_cooling_geom_devc.csv')]:
    if not os.path.exists(f): out.append(f'| {tag} | missing | |'); continue
    d = read(f); t, T = d['Time'], d['T_sphere']
    out.append(f'| {tag} | {np.max(np.abs(T-np.interp(t,tb,Tb))):.2e} | {np.max(np.abs(T-Tex(t))):.2f} |')
    ax[1].plot(t, T - Tex(t), label=tag)
ax[1].plot(tb, Tb - Tex(tb), 'k--', label='Single mesh')
ax[1].set_xlabel('Time (s)'); ax[1].set_ylabel('FDS - exact (K)'); ax[1].set_title('V2 variants'); ax[1].legend(fontsize=8); ax[1].grid(alpha=0.3)
fig.tight_layout(); fig.savefig(f'{R}/robustness.png', dpi=150)
open(f'{R}/summary_robustness.md', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
