"""Compare device output of the rebuilt branch with earlier results, column by column (max absolute difference)."""
import sys, csv, os
import numpy as np
NEW, OLD = sys.argv[1], sys.argv[2]   # OLD: results/verification
pairs = sys.argv[3:]
def read(p):
    rows = list(csv.reader(open(p))); names = [n.strip() for n in rows[1]]
    d = np.array([[float(v) for v in r] for r in rows[2:] if r]); return names, d
out = ['# Regression: rebuilt branch vs earlier results (identical inputs)', '', '| Case | Columns | Rows | Max abs difference |', '|---|---|---|---|']
worst = 0.
for pr in pairs:
    chid, sub = pr.split(':')
    fn, fo = f'{NEW}/{chid}_devc.csv', os.path.join(OLD, sub, f'{chid}_devc.csv')
    if not (os.path.exists(fn) and os.path.exists(fo)): out.append(f'| {chid} | missing | | |'); continue
    nn, dn = read(fn); no, do = read(fo); n = min(len(dn), len(do)); cols = [c for c in nn if c in no]
    diff = max(np.max(np.abs(dn[:n, nn.index(c)]-do[:n, no.index(c)])) for c in cols)
    worst = max(worst, diff); out.append(f'| {chid} | {len(cols)} | {n} (new {len(dn)}, old {len(do)}) | {diff:.3e} |')
out += ['', f'Largest difference over all cases: {worst:.3e}']
open(f'{NEW}/summary_regression.md', 'w').write('\n'.join(out)+'\n'); print('\n'.join(out))
