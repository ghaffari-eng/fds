"""Checks for the fixes made after the code review: pile cap, vertical walls, size distribution."""
import sys, os, math
import numpy as np
here = os.path.dirname(os.path.abspath(__file__))
R = sys.argv[1]; sys.argv = [sys.argv[0], R]
exec(open(os.path.join(here, '..', 'exact', 'analyse_lumped_exact.py')).read().split('cases = [')[0])
out = ['# Checks of the review fixes', '']
f = f'{R}/contact_pile_cap_devc.csv'
if os.path.exists(f):
    d = read(f); t, T = d['Time'], d['T_sphere']; pwt = d['PWT'][-1]; r = 0.005; Aw = 0.05**2
    F = min(1., Aw/(pwt*math.pi*r**2)); th, Bi = theta_surface('sphere', r, 500.*0.25*F, t); Tex = 20 + 880*th
    m = t > 0; e = np.max(np.abs(T[m]-Tex[m]))
    q = -d['CPUA_floor'][m]; ratio = q/np.maximum(T[m]-20., 1e-9)
    out += ['## V14. One particle standing for many spheres: total footprint larger than the floor cell', '',
            f'Weighting factor {pwt:.3f}; footprint {pwt*math.pi*r**2*1e4:.1f} cm2 on a {Aw*1e4:.0f} cm2 cell; reduction factor {F:.4f}',
            f'Sphere temperature vs exact (h = h_s F / 4): max difference {e:.3f} K ({100*e/880:.3f}%)',
            f'Floor heat flux / (T_p - T_w): {np.median(ratio[T[m]>100]):.4f} kW/m2/K (expected h_s = 0.5000 when capped)', '']
else: out += ['## V14: no output', '']
fa, fb = f'{R}/contact_side_wall_adhere_devc.csv', f'{R}/contact_side_wall_falls_devc.csv'
if os.path.exists(fa) and os.path.exists(fb):
    a = read(fa); b = read(fb); t, T = a['Time'], a['T_sphere']; th, Bi = theta_surface('sphere', 0.005, 125., t); Tex = 600 - 580*th
    m = t > 0
    out += ['## V15. Sphere on a vertical wall held at 600 C', '',
            f'Sticks to the wall (ADHERE_TO_SOLID): max difference from exact heating {np.max(np.abs(T[m]-Tex[m])):.3f} K; T at 200 s {T[-1]:.2f} C (exact {Tex[-1]:.2f} C)',
            f'Falls along the wall (no ADHERE_TO_SOLID): largest sphere temperature {b["T_sphere"].max():.3f} C (no contact with the wall, expected 20 C)', '']
else: out += ['## V15: no output', '']
f = f'{R}/contact_polydisperse_devc.csv'
if os.path.exists(f):
    d = read(f)
    out += ['## V13. Spheres drawn from a size distribution (nominal r 5 mm, actual 3-4 mm)', '', '| Sphere | Lost (kJ) | Gained by its floor cell (kJ) | Final imbalance (%) |', '|---|---|---|---|']
    for x in 'abc':
        L, G = -d[f'H_{x}'], d[f'G_{x}']
        out.append(f'| {x} | {L[-1]:.4f} | {G[-1]:.4f} | {100*(G[-1]-L[-1])/L[-1]:+.3f} |')
    out.append('')
else: out += ['## V13: no output', '']
open(f'{R}/summary_review.md', 'w').write('\n'.join(out)+'\n'); print('\n'.join(out))
