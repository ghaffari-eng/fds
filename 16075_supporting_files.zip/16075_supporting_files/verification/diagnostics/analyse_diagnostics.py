"""Diagnostics: (1) V3 offset is the default stretched wall grid; (2) restart is exact when the device output interval is the same;
(3) V2 error against the exact solution with instantaneous device output."""
import sys, csv, math, os
import numpy as np
from scipy.special import erfcx
R = sys.argv[1]; R0 = sys.argv[2]
def read(p):
    rows = list(csv.reader(open(p))); names = [n.strip() for n in rows[1]]
    d = np.array([[float(v) for v in r] for r in rows[2:] if r]); return {n: d[:, i] for i, n in enumerate(names)}
out = ['# Diagnostics', '']
# 1
k, rs, cs = 0.2, 500., 1500.; a = k/(rs*cs); he = 500.*math.pi*0.005**2/0.02**2
Tan = lambda t: 20 + 580*(1-erfcx(he*np.sqrt(a*t)/k))
out += ['## 1. V3 with a uniform 0.125 mm wall grid in the floor (400 cells) vs the default stretched grid (16 cells)', '',
        '| Floor wall grid | T_s at 10 s (C) | T_s at 60 s (C) | Max difference from exact, 1-60 s (K) | 5-60 s (K) | 10-60 s (K) | at 60 s (K) |', '|---|---|---|---|---|---|---|']
for tag, f in [('Default (CELL_SIZE_FACTOR=0.25, stretch 2)', f'{R0}/contact_slab_heating_devc.csv'),
               ('Uniform, CELL_SIZE=1.25E-4 m', f'{R}/contact_slab_heating_uniform_devc.csv')]:
    if not os.path.exists(f): out.append(f'| {tag} | no output | | |'); continue
    d = read(f); t, Ts = d['Time'], d['T_floor_cell']; m = t >= 1.
    e = np.abs(Ts-Tan(np.maximum(t, 1.e-12)))
    out.append(f'| {tag} | {np.interp(10, t, Ts):.2f} | {Ts[-1]:.2f} | {e[m].max():.2f} | {e[t>=5].max():.2f} | {e[t>=10].max():.2f} | {e[-1]:.2f} |')
out += ['', f'Exact at 10 s: {Tan(10.):.2f} C; at 60 s: {Tan(60.):.2f} C',
        'With the uniform grid the error falls with time. What remains early is the start: contact begins once the particle has landed, and the device output is averaged over each output interval.', '']
# 2
f = f'{R}/contact_restart2_devc.csv'
if os.path.exists(f):
    d = read(f); b = read(f'{R0}/contact_sphere_cooling_devc.csv')
    n = min(len(d['Time']), len(b['Time'])); same = np.abs(d['Time'][:n]-b['Time'][:n]) < 1.e-6
    dT = np.abs(d['T_sphere'][:n]-b['T_sphere'][:n]); dq = np.abs(d['CPUA_floor'][:n]-b['CPUA_floor'][:n]); pre = d['Time'][:n] <= 100.
    out += ['## 2. Stop at 100 s and restart to 200 s, same device output interval as the reference run', '',
            f'Rows compared: {n}; rows written at the same time in both runs: {int(same.sum())} (after the restart some rows are written one time step apart)',
            f'At the same output times: max sphere temperature difference {dT[same&pre].max():.3e} K before the restart, {dT[same&~pre].max():.3e} K after; '
            f'max floor CPUA difference {dq[same].max():.2e} kW/m2',
            'Note: devices with RELATIVE=.TRUE. (here H_sphere) start again from zero after a restart, because DV%INITIAL_VALUE is not saved in the restart file (dump.f90, DUMP_RESTART and READ_RESTART). This is in unmodified FDS, not in this change.', '']
else: out += ['## 2: no output (see job log)', '']
# 3
f = f'{R}/contact_sphere_cooling_inst_devc.csv'
if os.path.exists(f):
    d = read(f); t, T = d['Time'], d['T_sphere']; tau = 4*7850.*460.*0.005/(3*500.)
    e = np.abs(T-(20+880*np.exp(-t/tau)))
    out += ['## 3. V2 with instantaneous device output (TIME_AVERAGED=.FALSE.)', '',
            f'tau = 4 rho c r/(3 h_s) = {tau:.2f} s; max difference from exact: {e.max():.2f} K ({100*e.max()/880:.2f}% of the 880 K drop) at t = {t[np.argmax(e)]:.1f} s', '']
else: out += ['## 3: no output (see job log)', '']
open(f'{R}/summary_diagnostics.md', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
