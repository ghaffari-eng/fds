"""Extra verification: cylinder and plate footprints, particle weighting factor, specified-temperature particle without MATL, particle on an OBST."""
import sys, csv, math, os
import numpy as np
from scipy.special import erfcx
R = sys.argv[1]; R0 = sys.argv[2]
def read(p):
    rows = list(csv.reader(open(p))); names = [n.strip() for n in rows[1]]
    d = np.array([[float(v) for v in r] for r in rows[2:] if r]); return {n: d[:, i] for i, n in enumerate(names)}
rho, c, h_s = 7850., 460., 500.
out = ['# Extra verification', '']
def lumped(case, tau, label):
    f = f'{R}/{case}_devc.csv'
    if not os.path.exists(f): return [f'## {label}: no output (see job log)', '']
    d = read(f); t, T = d['Time'], d['T_sphere']; Tex = 20 + 880*np.exp(-t/tau); e = np.max(np.abs(T-Tex))
    return [f'## {label}', '', f'tau = {tau:.2f} s; T at {t[-1]:.0f} s: FDS {T[-1]:.2f} C, exact {Tex[-1]:.2f} C; max difference {e:.2f} K ({100*e/880:.2f}%)', '']
Rc, L = 0.0032, 0.038
out += lumped('contact_cylinder_cooling', rho*c*math.pi*Rc/(2*h_s), 'V6a. Steel cylinder lying on a 20 C floor (footprint 2 r L, area ratio 1/pi)')
t_half = 0.003
out += lumped('contact_plate_cooling', 2*rho*c*t_half/h_s, 'V6b. Steel plate lying on a 20 C floor (footprint L W, area ratio 1/2)')
f = f'{R}/contact_energy_budget_pwt4_devc.csv'
if os.path.exists(f):
    d = read(f); Hs, Hf = d['H_sphere'], d['H_floor_cell']; pwt = d['PWT'][-1]
    out += ['## V7. One computational particle standing for several real spheres (weighting factor)', '',
            f'Particle weighting factor: {pwt:.3f}. WALL ENTHALPY of a particle already includes the weighting factor (dump.f90, WALL ENTHALPY).',
            f'Energy lost by the {pwt:.3f} real spheres: {-Hs[-1]:.4f} kJ ({-Hs[-1]/pwt:.4f} kJ each); gained by the floor cell: {Hf[-1]:.4f} kJ; ratio {Hf[-1]/(-Hs[-1]):.4f} (should be 1)', '']
else: out += ['## V7: no output (see job log)', '']
f = f'{R}/contact_slab_heating_nomatl_devc.csv'
if os.path.exists(f):
    d = read(f); d3 = read(f'{R0}/contact_slab_heating_devc.csv'); t = d['Time']
    k, rs, cs = 0.2, 500., 1500.; he = h_s*math.pi*0.005**2/0.02**2
    Tex = 20 + 580*(1-erfcx(he*np.sqrt(k/(rs*cs)*t)/k))
    out += ['## V8. Particle with a specified surface temperature and no MATL (explicit branch)', '',
            f'T_s at 60 s: FDS {d["T_floor_cell"][-1]:.2f} C; V3 (thermally thick particle) {d3["T_floor_cell"][-1]:.2f} C; exact {Tex[-1]:.2f} C',
            f'Max difference from V3: {np.max(np.abs(d["T_floor_cell"]-np.interp(t, d3["Time"], d3["T_floor_cell"]))):.3f} K over 0-60 s; '
            f'{np.max(np.abs(d["T_floor_cell"]-np.interp(t, d3["Time"], d3["T_floor_cell"]))[t>=1.]):.3f} K over 1-60 s',
            'The early difference is the start: the particle surface is at ambient at t = 0 and is set to 600 C at the first step, so contact starts one step later than in V3.', '']
else: out += ['## V8: no output (see job log)', '']
f = f'{R}/contact_sphere_cooling_obst_devc.csv'
if os.path.exists(f):
    d = read(f); d2 = read(f'{R0}/contact_sphere_cooling_devc.csv')
    out += ['## V9. Sphere resting on top of an OBST held at 20 C', '',
            f'Max difference from V2 (sphere on the domain floor): {np.max(np.abs(d["T_sphere"]-np.interp(d["Time"], d2["Time"], d2["T_sphere"]))):.3e} K', '']
else: out += ['## V9: no output (see job log)', '']
open(f'{R}/summary_extra.md', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
