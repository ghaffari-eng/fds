"""Verification of contact heat transfer between a resting solid particle and the surface below it (V1-V3)."""
import sys, csv, math
import numpy as np
from scipy.special import erfcx
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R = sys.argv[1]
def read(path):
    rows = list(csv.reader(open(path)))
    names = [n.strip() for n in rows[1]]
    data = np.array([[float(v) for v in r] for r in rows[2:] if r])
    return {n: data[:, i] for i, n in enumerate(names)}

r, rho, c = 0.005, 7850., 460.
m_c = rho * 4/3 * math.pi * r**3 * c          # J/K
A_c = math.pi * r**2                           # projected area of a sphere
h_s = 500.
out = ['# Verification: contact conduction between a resting particle and the surface below it', '']
fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))

# V2: lumped sphere on a floor held at 20 C
d = read(f'{R}/contact_sphere_cooling_devc.csv')
t, T = d['Time'], d['T_sphere']
tau = m_c / (h_s * A_c)
T_an = 20 + 880 * np.exp(-t / tau)
err2 = np.max(np.abs(T - T_an))
q_floor = -d['CPUA_floor'] * 1000 * 0.05**2       # W into the floor cell
q_exp = h_s * A_c * (T - 20)
m = t > 1
ratio2 = np.mean(q_floor[m] / q_exp[m])
out += ['## V2. Steel sphere (r = 5 mm) cooling on a floor held at 20 C, contact only (h_s = 500 W/m2/K)', '',
        f'Exact solution: T = 20 + 880 exp(-t/tau), tau = m c / (h_s pi r^2) = {tau:.2f} s',
        f'T at 50 s: FDS {np.interp(50,t,T):.2f} C, exact {np.interp(50,t,T_an):.2f} C',
        f'T at 150 s: FDS {np.interp(150,t,T):.2f} C, exact {np.interp(150,t,T_an):.2f} C',
        f'Maximum difference 0-200 s: {err2:.2f} K ({100*err2/880:.2f}% of the initial difference)',
        f'Heat received by the floor cell / h_s A_c (T_p - T_w): {ratio2:.4f} (mean over t > 1 s)', '']
ax[0].plot(t, T, label='FDS'); ax[0].plot(t, T_an, '--', label='Exact')
ax[0].set_title('V2: sphere cooling on a 20 C floor'); ax[0].set_xlabel('Time (s)'); ax[0].set_ylabel('Sphere temperature (C)')
ax[0].legend(); ax[0].grid(alpha=0.3)

# V1: energy budget, sphere on a thermally thick slab
d = read(f'{R}/contact_energy_budget_devc.csv')
t = d['Time']; Hs, Hf = d['H_sphere'], d['H_floor_cell']
S = Hs + Hf
rel = np.max(np.abs(S)) / np.max(np.abs(Hs))
out += ['## V1. Energy budget: steel sphere on a thermally thick slab (contact only, no radiation, no convection)', '',
        f'Energy lost by the sphere at the end: {-Hs[-1]:.4f} kJ; gained by the floor cell: {Hf[-1]:.4f} kJ',
        f'Largest imbalance over the run: {np.max(np.abs(S)):.2e} kJ = {100*rel:.3f}% of the energy transferred',
        f'Final temperatures: sphere {d["T_sphere"][-1]:.1f} C, floor cell surface {d["T_floor_cell"][-1]:.1f} C', '']
ax[1].plot(t, -Hs, label='Lost by sphere'); ax[1].plot(t, Hf, '--', label='Gained by floor cell'); ax[1].plot(t, S, ':', label='Sum')
ax[1].set_title('V1: energy budget'); ax[1].set_xlabel('Time (s)'); ax[1].set_ylabel('Energy (kJ)'); ax[1].legend(); ax[1].grid(alpha=0.3)

# V3: sphere held at 600 C on a thick slab, semi-infinite solid with a convective-type boundary condition
d = read(f'{R}/contact_slab_heating_devc.csv')
t, Ts = d['Time'], d['T_floor_cell']
k, rho_s, c_s = 0.2, 500., 1500.
alpha = k / (rho_s * c_s)
h_eff = h_s * A_c / 0.02**2
beta = h_eff * np.sqrt(alpha * t) / k
T_an = 20 + 580 * (1 - erfcx(beta))
m = t > 1
err3 = np.max(np.abs(Ts[m] - T_an[m]))
out += ['## V3. Sphere held at 600 C on a thick slab (k = 0.2 W/m/K, rho = 500 kg/m3, c = 1.5 kJ/kg/K)', '',
        f'Heat is spread over the 2 cm x 2 cm floor cell: h_eff = h_s A_c / A_cell = {h_eff:.2f} W/m2/K',
        'Exact (Carslaw and Jaeger): T_s = T_i + (T_p - T_i) [1 - exp(b^2) erfc(b)], b = h_eff sqrt(alpha t)/k',
        f'T_s at 10 s: FDS {np.interp(10,t,Ts):.2f} C, exact {np.interp(10,t,T_an):.2f} C',
        f'T_s at 60 s: FDS {Ts[-1]:.2f} C, exact {T_an[-1]:.2f} C',
        f'Maximum difference 1-60 s: {err3:.2f} K',
        f'Neighbouring floor cell at 60 s: {d["T_neighbour"][-1]:.2f} C (should stay 20 C)', '']
ax[2].plot(t, Ts, label='FDS'); ax[2].plot(t, T_an, '--', label='Exact')
ax[2].set_title('V3: slab surface under a 600 C sphere'); ax[2].set_xlabel('Time (s)'); ax[2].set_ylabel('Surface temperature (C)')
ax[2].legend(); ax[2].grid(alpha=0.3)

fig.tight_layout(); fig.savefig(f'{R}/verification_V1_V3.png', dpi=150)
open(f'{R}/summary_V1_V3.md', 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
