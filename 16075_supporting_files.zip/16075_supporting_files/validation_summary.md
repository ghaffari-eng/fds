# Validation and measured values of h_s (Issue #16075)

8 Nov 2026, revised after the fact-check. Papers read: Wessies and Ezekoye (2022); Wessies PhD dissertation (2021, Ch. 4); Mensch, Wessies and Veley (2026); Cooper, Mikic and Yovanovich (1969).

## 1. Measured contact conductance for a flat hot object: Wessies and Ezekoye (2022)

Experiment: Inconel 625 cylinder (D 19 mm, H 10 mm, black coating, emissivity 0.95), heated to about 880 C (the paper says between 800 and 900 C) and placed flat on calcium silicate (CS), 304 stainless steel (SS) or aluminium (Al) plates 25.4 mm thick, cooled by an impinging air jet. Fig. 13 gives the cylinder temperature for 60 s at two jet speeds.

Inverse analysis (`wessies_inverse.py`):
- Data: Fig. 13 curves digitised from the embedded figure image (`digitize13.py`, `fig13_digitized.json`).
- Cylinder: lumped (Biot < 0.02); Inconel 625 density and specific heat from the Special Metals data sheet (2013).
- Radiation from the top and sides (8.80 cm2), emissivity 0.95.
- Convection: the authors' bedded correlation, Nu_D = 2.3936 Re^0.2937. It is printed only in the dissertation (Sec. 4.3.2); the journal paper shows it only in Fig. 6. Air conductivity at the film temperature (Incropera Table A.4).
- Conduction: contact conductance h_c over the bottom face (2.84 cm2), in series with 2-D axisymmetric transient conduction in the plate (Incropera Table A.1 properties for SS and Al).
- h_c fitted to the lower-flow curve of each material; the higher-flow curve is then predicted with the same h_c.

| Substrate | Fitted h_c (W/m2/K) | RMS error, fit (K) | Other jet speed, predicted (K) | No contact, RMS (K) | Perfect contact, RMS (K) |
|---|---|---|---|---|---|
| Stainless steel | 528 (470-670) | 4.6 | RMS 2.9, largest 6.4 | 142 | 322 |
| Aluminium | 651 (610-700) | 4.0 | RMS 23-34 | 195 | 465 |
| Calcium silicate | not identifiable | 6.3 | | 11.5 | 6.5 |

- The higher-flow curve is not visible before 5.1 s, so its starting temperature is assumed (885 C on SS). Assuming 880-895 C gives RMS 2.9-6.4 K on SS.
- On SS and Al the conductance is well defined: no contact or perfect contact are off by 140-470 K.
- Sensitivity (`inverse_sensitivity.log`, current): on SS, convection +/-20% gives h_c = 468-588 W/m2/K, and air conductivity at room temperature instead of film temperature gives 667. On Al, convection +/-20% gives 611-698. `inverse_fit.log` was regenerated on 8 Nov with the current script (SS 2.94 K, Al 33.3 K at the other jet speed); the earlier copy (SS 3.62, Al 23.14) was from an 880 C start for the higher-flow curves.
- On Al, the prediction at the other jet speed is 23 K RMS with an 880 C start and 33 K with 905 C, so the Al value is less certain than the SS value.
- On CS the low-conductivity substrate limits the heat flow, so the result hardly depends on h_c. This agrees with the authors' own fit (their R = 0.0073 sqrt(t) is below the semi-infinite resistance sqrt(pi t)/e = 0.0084 sqrt(t)).
- h_c is an all-mode value across the interface. Gap radiation is about 26 W/m2/K on SS (emissivity 0.3) and 9 on Al, so the conduction part is about 500-640 W/m2/K. For a uniform air gap, k/s with k at about 650 K gives s of about 0.1 mm, in line with the flat-face row of our guidance table. FDS's h_s excludes radiation, so using h_c directly in FDS double-counts gap radiation by about 5%.

## 2. FDS replica of the same test (jobs 019 and 020)

FDS has no upright-disc particle, so the cylinder is a CARTESIAN particle with the cylinder's mass and exposed area. HEAT_TRANSFER_COEFFICIENT_SOLID is scaled by footprint so that h_s A_c = h_c x 2.84 cm2. h_c = 528 W/m2/K on CS and SS (job 019), and 651 on Al (job 020, `wessies_Al_contact651.fds`). Convection is set from the same correlation; radiation is solved by FDS. Grid 2.4 x 2.4 x 6 cm. Lower jet speed; RMS over 2-60 s.

| Substrate | h_c used | FDS with contact: RMS (K) | FDS without contact: RMS (K) | Measured T at 60 s | FDS with / without contact at 60 s |
|---|---|---|---|---|---|
| Calcium silicate | 528 | 8.4 | 31 | 508 C | 494 / 541 C |
| Stainless steel | 528 | 17.8 | 169 | 327 C | 350 / 558 C |
| Aluminium | 528 | 61.8 (max 81.5) | 222 | 258 C | 338 / 555 C |
| Aluminium | 651 | 35.9 (max 52.5) | 222 | 258 C | 309 / 555 C |

- Without contact FDS gives nearly the same cooling on all three plates (541-558 C at 60 s; the CS test had a slightly faster jet, Re about 5900 vs 4500). With contact it reproduces the measured effect of the plate material.
- On aluminium the cylinder still cools too slowly. Two reasons:
  - The wall is solved in 1-D, so heat cannot spread sideways in a 25 mm aluminium plate. The plate surface under the cylinder reaches 150 C at 60 s (135 C with 528). This is the known 1-D wall limitation, not the contact model.
  - Radiation check on this grid: radiation-only cooling is 17.5 K slower than exact at 60 s (674.0 vs 656.6 C), from particle self-absorption in its cell. This affects all three plates.
- Figure: `results/figures/fig5_wessies_validation.png` (Al curve with 651).

## 3. Glowing wood disks: Mensch, Wessies and Veley (2026)

- Peak net heat flux into a thin-skin calorimeter: 35-84 kW/m2 on ceramic fibre board and 22-62 kW/m2 on silicone. Firebrand top-surface temperature 747-1011 K (IR average over the first 5 s, emissivity 0.8; Table 3).
- All-mode effective coefficient q_peak / (T_FB - 295 K): about 31-146 W/m2/K (birch, 84 kW/m2: 131-146; cedar, 22 kW/m2: 31-38). So at most about 150 W/m2/K.
- Black-body radiation at the top-surface temperature is the most radiation can be: 38 W/m2/K at 747 K and 82 W/m2/K at 1011 K. Real radiation is lower: the bottom is quenched on contact (Mensch et al.), glowing is concentrated on the top and leading edge, and the copper gauge's absorptivity is not stated.
- So "total minus black-body" is a lower estimate of conduction, not an upper bound. The firm statement is the all-mode upper bound: conduction is at most about 150 W/m2/K, several times lower than for the metal cylinder. For a flat face that is a gap of at least about 0.35 mm (k/h at 700 K).
- Mensch et al. also report that Bearinger et al. (2021) found peak fluxes averaged over the firebrand footprint all below 30 kW/m2, with local peaks up to 105.8 kW/m2.

## 4. What this means for McGrattan's point 3

- There is no single default. Two measured anchors: a flat-bottomed metal cylinder on a flat plate, h_s about 500-650 W/m2/K; a glowing wood ember, at most about 150 W/m2/K for all modes together.
- So 25 W/m2/K is too low for smooth contact, and the "contact fraction" idea is replaced by the footprint area and one coefficient.
- Cooper, Mikic and Yovanovich (1969), Sec. 5, Eq. 9: A_r/A_a = p/H for plastic contacts, with H the microhardness of the softer material. The paper treats contact in a vacuum, so the gas gap is a separate path. For a sub-gram ember, p is about 20-50 Pa. With steel hardness, p/H is about 1e-8; with H about 20 MPa (plausible for char) it is about 1e-6. Hence "of order 1e-6 or less".

## References
- Wessies, S.S., Ezekoye, O.A. (2022). Cooling of Heated Solid Cylinder Supported on Bedded and Embedded Substrates by Impinging Air Jet. J. Thermal Sci. Eng. Appl. 14(1):011009. doi:10.1115/1.4050837
- Wessies, S.S. (2021). Firebrand ignition: characterization of heat transfer mechanisms. PhD dissertation, University of Texas at Austin (copyright 2021). doi:10.26153/tsw/42026
- Mensch, A.E., Wessies, S.S., Veley, E.M. (2026). Experimental Investigation of Factors Affecting Individual Firebrand Heat Transfer. ASME J. Heat Mass Transfer 148(8):081301. doi:10.1115/1.4071850
- Bearinger, E.D., Hodges, J.L., Yang, F., Rippe, C.M., Lattimer, B.Y. (2021). Localized heat transfer from firebrands to surfaces. Fire Safety J. 120:103037. doi:10.1016/j.firesaf.2020.103037 (cited only through Mensch et al.; not read)
- Cooper, M.G., Mikic, B.B., Yovanovich, M.M. (1969). Thermal contact conductance. Int. J. Heat Mass Transfer 12:279-300. doi:10.1016/0017-9310(69)90011-8
- Special Metals Corporation (2013). INCONEL alloy 625 data sheet (density, specific heat, conductivity).
- Incropera, F.P., DeWitt, D.P., Bergman, T.L., Lavine, A.S. Fundamentals of Heat and Mass Transfer, Tables A.1 and A.4.
