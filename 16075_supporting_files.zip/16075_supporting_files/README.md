# Supporting files for FDS Issue #16075: contact conduction between resting solid particles and surfaces

Branch: ghaffari-eng/fds:particle-surface-heat-transfer (up to date with firemodels/fds master 7ea9716).
The three verification cases for the FDS suite are on the branch (Verification/Heat_Transfer/particle_contact_*).
This archive holds everything else behind the reply: inputs, analysis scripts and the main results.
The analysis scripts take the input and output folders as arguments; some default to the author's folder layout.

| Folder | What it is |
|---|---|
| baseline_master/ | Unmodified FDS: radiation from a 900 C sphere resting on a 20 C floor (loss against exact, share reaching the floor, 1/2/5 cm cells) |
| radiation_beneath/ | Unmodified FDS: where the floor-bound radiation of a resting sphere lands (5 and 10 cm cells), with results |
| verification/ | All verification inputs for the new term (exact cooling of sphere, cylinder and plate; slab vs Carslaw and Jaeger; energy budget; convergence; OBST, GEOM, 2 meshes, OpenMP, restart, debug build; pile limit; side wall with and without ADHERE_TO_SOLID; size distribution) |
| validation_wessies/ | FDS replica of Wessies and Ezekoye (2022): inputs, input generator, inverse analysis of their Fig. 13 (digitised data, script, logs) and the FDS results |
| demo_hot_rods/ | Verification/WUI/hot_rods with h_s = 0, 50 and 200 W/m2/K |
| hs_guidance/ | Gas-gap conduction table for choosing h_s (script and table) |
| figures/ | Scripts for the figures in the reply (make_figures.py: Figs. 1-3; fig5_wessies.py: Fig. 4; fig4_hot_rods.py: Fig. 5) |
| validation_summary.md | Notes on the inverse analysis, the FDS replica and the Mensch et al. (2026) data |
